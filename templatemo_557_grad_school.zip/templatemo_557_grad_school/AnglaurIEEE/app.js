const http =require('http');
http.createServer((request,Response)=>
{
//ok
    Response.statusCode=200;
    Response.write('<h1>Hello node</h1>');
    //to close
    Response.end();

}).listen(3000);
console.log("server run...")